gene = xlsread('gene.xlsx')
roi = xlsread('roi.xlsx')
snp = xlsread('snp.xlsx')

corr1 = corr(roi, snp);
corr2 = corr(roi, gene);