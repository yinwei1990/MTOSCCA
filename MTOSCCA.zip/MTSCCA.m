function [U, V] = MTSCCA(data, opts)
[~, p] = size(data.X); 
[~,  q] = size(data.Y{1}); 
n = data.n_modality; 
X = data.X;
Y = data.Y;
U = ones(p, n);
V = ones(q, n);

for m = 1 : n
    X = normalize(X);
    Y{m} = normalize(Y{m});
     
    XX = X' * X;
    XY{m} = X' * Y{m};
    YY{m} = Y{m}' * Y{m};
    YX{m} = XY{m}';
    
    U(:, m) = U(:, m) / norm(X * U(:, m));
    V(:, m) = V(:, m) / norm(Y{m} * V(:, m));
end
lambda_u1 = opts.lambda_u1; 
lambda_u3 = opts.lambda_u3;  
lambda_v1 = opts.lambda_v1; 
lambda_v2 = opts.lambda_v2; 
lambda_v3 = opts.lambda_v3;  
gamma_u = 0;
gamma_v = 0;
max_Iter = 25;
t = 0;
tol = 1e-5;
tu = inf;
tv = inf;
while (t < max_Iter && (tu > tol || tv > tol))
    t = t + 1;
    U_old = U;
    V_old = V;
    
    D11 = updateD(V); 
    for m = 1 : n
        D12 = updateD(V(:, m)); 
        
        VP1 = YY{m} + lambda_v1 * D11 + (gamma_v + 1) * YY{m};
        VP2 = Y{m}' * X * U(:, m);
        V(:, m) = VP1 \ VP2;

        V(:, m) = V(:, m) / norm(Y{m} * V(:, m));
    end
    
    D21 = updateD(U); 
    for m = 1 : n
%         D22 = updateD(U(:, m)); 
%         F1 = lambda_u1 * D21 + lambda_u2 * D22 + (gamma_u + 1) * XX + 2* lambda_u3 * (U(:, m)*U(:, m)'-eye(p));
        F1 = lambda_u1 * D21 + (gamma_u + 1) * XX;
        b1 = XY{m} * V(:, m);
        U(:, m) = F1 \ b1;
        U(:, m) = U(:, m) / norm(X * U(:, m));
    end
    tu = max(max(abs(U - U_old)));
    tv = max(max(abs(V - V_old)));

end

function D = updateD(W)
d = 1 ./ sqrt(sum(W .^ 2, 2) + eps);
D = diag(0.5 * d);

function Y = normalize(X)
X0 = X - mean(X);
Y = X0 ./ (sqrt(sum(X0 .^ 2)) + eps);

function [d, sub_group_obj_square] = updateD_G(beta,group_idx)
idx = unique(group_idx,'stable');
n_g = length(idx);
obj = 0;
for i = 1:n_g
    u_idx = find(group_idx == idx(i));
    wc1 = beta(u_idx, :);
    di = sqrt(sum(sum(wc1.*wc1))+eps); 
    snp_wi(u_idx) = di;
    obj(i) = di;
end
d = 0.5 ./ snp_wi;
sub_group_obj_square = sum(obj);







