Data.X = csvread('../python/x_train_smri_noname.csv');
Data.Y{1,1} = csvread('../python/x_train_snp_noname.csv');
Data.Y{1,2} = csvread('../python/x_train_gene_noname.csv');
Data.n_modality = 2;
n = 110;

count = 1;

opts.lambda_u1 = 0.1;    
opts.lambda_u3 = 0.1;   
opts.lambda_v1 = 0.01;  
opts.lambda_v2 = 0.001;   
opts.lambda_v3 = 0.01;

[U, V] = MTSCCAR(Data, opts);
u = mean(U,2);
v1 = V(:,1);
v2 = V(:,2);

CCCuv11 = corr(Data.X*u, Data.Y{1,1}*v1);
CCCuv22 = corr(Data.X*u, Data.Y{1,2}*v2);

[U1, V1] = MTSCCA(Data, opts);
u1 = mean(U1,2);
v11 = V1(:,1);
v21 = V1(:,2);

CCCuv111 = corr(Data.X*u, Data.Y{1,1}*v11);
CCCuv222 = corr(Data.X*u, Data.Y{1,2}*v21);

% figure
% subplot(311);
% imagesc(Data.u_0gt);
% set(gca,'yticklabel',[])
% title('Ground truth u_0');
% subplot(312);
% imagesc(Data.v_0gt);
% set(gca,'yticklabel',[])
% title('Ground truth v_0');
% subplot(313);
% imagesc(Data.v_1gt);
% set(gca,'yticklabel',[])
% title('Ground truth v_1');

figure
subplot(311);
imagesc(u', [-0.001 0.001]);
set(gca,'yticklabel')
title('Estimated u');
colorbar
subplot(312);
imagesc(v1', [-0.3 0.3]);
set(gca,'yticklabel',[])
title('Estimated v1');
colorbar
subplot(313);
imagesc(v2', [-0.3 0.3]);
set(gca,'yticklabel',[])
title('Estimated v2');
colorbar

u = abs(u);
v1 = abs(v1);
v2 = abs(v2);

