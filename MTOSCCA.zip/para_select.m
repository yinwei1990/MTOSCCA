Data.X = csvread('../python/x_train_smri_noname.csv');
Data.Y{1,1} = csvread('../python/x_train_snp_noname.csv');
Data.Y{1,2} = csvread('../python/x_train_gene_noname.csv');
Data.n_modality = 2;
n = 110;

count = 1;
paraset = [0.001 0.01 0.1 1];
for i1 = 1:4
    for i2 = 1:4
        for i3 = 1:4
            for i4 = 1:4 
                for i5 = 1:4
opts.lambda_u1 = paraset(i1);    
opts.lambda_u3 = paraset(i2);   
opts.lambda_v1 = paraset(i3);  
opts.lambda_v2 = paraset(i4);   
opts.lambda_v3 = paraset(i5);

[U, V] = MTSCCAR(Data, opts);
u = mean(U,2);
v1 = V(:,1);
v2 = V(:,2);

CCCuv1(count) = corr(Data.X*u, Data.Y{1,1}*v1);
CCCuv2(count) = corr(Data.X*u, Data.Y{1,2}*v2);
para{count} = [opts.lambda_u1 opts.lambda_u3 opts.lambda_v1 opts.lambda_v2 opts.lambda_v3];
count
count = count + 1;
                end
            end
        end
    end
end

% figure
% subplot(311);
% imagesc(Data.u_0gt);
% set(gca,'yticklabel',[])
% title('Ground truth u_0');
% subplot(312);
% imagesc(Data.v_0gt);
% set(gca,'yticklabel',[])
% title('Ground truth v_0');
% subplot(313);
% imagesc(Data.v_1gt);
% set(gca,'yticklabel',[])
% title('Ground truth v_1');

figure
subplot(311);
imagesc(u', [-0.1 0.1]);
set(gca,'yticklabel')
title('Estimated u_0');
colorbar
subplot(312);
imagesc(v1', [-0.1 0.1]);
set(gca,'yticklabel',[])
title('Estimated v_0');
colorbar
subplot(313);
imagesc(v2', [-0.1 0.1]);
set(gca,'yticklabel',[])
title('Estimated v_1');
colorbar
