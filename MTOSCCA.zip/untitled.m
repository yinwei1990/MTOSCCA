count = 1;
paraset = [0.001 0.01 0.1 1];
for i1 = 1:4
    for i2 = 1:4
        for i3 = 1:4
            for i4 = 1:4 
                for i5 = 1:4
opts.lambda_u1 = paraset(i1);    
opts.lambda_u3 = paraset(i2);   
opts.lambda_v1 = paraset(i3);  
opts.lambda_v2 = paraset(i4);   
opts.lambda_v3 = paraset(i5);
count
para{count} = [opts.lambda_u1 opts.lambda_u3 opts.lambda_v1 opts.lambda_v2 opts.lambda_v3];
count = count + 1;
                end
            end
        end
    end
end
