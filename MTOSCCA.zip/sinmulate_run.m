clear all
rng(1)
sig_noise = 16; % Change if necessary
n = 100;
p = 90;
q = 650;
% Ground truth
u0_gt = [ones(1,3) zeros(1,25) ones(1,2) zeros(1,20) ones(1,10) zeros(1,20) ones(1,2) zeros(1,25) ones(1,3)  zeros(1,10) ones(1,10) zeros(1,10) ones(1,10) zeros(1,50) ones(1,50) zeros(1,400)];
v0_gt = [ones(1,1) zeros(1,20) ones(1,2) zeros(1,20) ones(1,2) zeros(1,20) ones(1,5) zeros(1,20) ];
v1_gt = [ones(1,1) zeros(1,35) ones(1,2) zeros(1,5) ones(1,2) zeros(1,20) ones(1,5) zeros(1,20) ];

% Generate latent variable
z = randn(n,1);
z = sign(z).*(abs(z)+0.1);
z = zscore(z);
z1 = randn(n,1);
z1 = sign(z1).*(abs(z1)+0.1);
z1 = zscore(z1);

% Generate X and Y
data.X{1,1} = z*u0_gt + randn(n,q)*sig_noise;
data.X{2,1} = data.X{1};
data.Y{1,1} = z*v0_gt + randn(n,p)*sig_noise;
data.Y{2,1} = z*v1_gt + randn(n,p)*sig_noise;

Data.X = z*u0_gt + randn(n,q)*sig_noise;
Data.Y{1,1} = z*v0_gt + randn(n,p)*sig_noise;
Data.Y{1,2} = z*v1_gt + randn(n,p)*sig_noise;
Data.n_modality = 2;

count = 1;

opts.lambda_u1 = 0.1;    
opts.lambda_u3 = 0.01;   
opts.lambda_v1 = 0.1;  
opts.lambda_v2 = 0.1;   
opts.lambda_v3 = 0.01;

[U, V] = MTSCCAR(Data, opts);
u = mean(U,2);
v1 = V(:,1);
v2 = V(:,2);

CCCuv11 = corr(Data.X*u, Data.Y{1,1}*v1);
CCCuv22 = corr(Data.X*u, Data.Y{1,2}*v2);


[U, V] = MTSCCA(Data, opts);
u = mean(U,2);
v1 = V(:,1);
v2 = V(:,2);

CCCuv111 = corr(Data.X*u, Data.Y{1,1}*v1);
CCCuv222 = corr(Data.X*u, Data.Y{1,2}*v2);

% figure
% subplot(311);
% imagesc(Data.u_0gt);
% set(gca,'yticklabel',[])
% title('Ground truth u_0');
% subplot(312);
% imagesc(Data.v_0gt);
% set(gca,'yticklabel',[])
% title('Ground truth v_0');
% subplot(313);
% imagesc(Data.v_1gt);
% set(gca,'yticklabel',[])
% title('Ground truth v_1');

figure
subplot(311);
imagesc(u');
set(gca,'yticklabel',[])
title('Estimated u_0');
subplot(312);
imagesc(v1');
set(gca,'yticklabel',[])
title('Estimated v_0');
subplot(313);
imagesc(v2');
set(gca,'yticklabel',[])
title('Estimated v_1');

u = abs(u);
v1 = abs(v1);
v2 = abs(v2);

